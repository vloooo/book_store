sold_last_book = 'Sorry, we have just sold the last book copy. You can choose another book from list.'

order_approved = 'Your order was successfully approved!'

order_canceled = 'Your order was successfully canceled!'


def scs_msg(subject, particeple):
    return f'The {subject} was successfully {particeple}!'
