from django.apps import AppConfig


class StorefrontConfig(AppConfig):
    name = 'storefront'
