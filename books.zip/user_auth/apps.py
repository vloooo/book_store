from django.apps import AppConfig


class UserAuthConfig(AppConfig):
    name = 'user_auth'
